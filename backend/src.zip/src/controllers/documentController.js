const Document=require("../models/Document");
const Comment=require("../models/Comment");


// Get all available documents

exports.getDocuments=async(req,res)=>{

try{

const documents=
await Document.find({
allowedRoles:{
$in:[req.user.role]
}
})
.populate("uploadedBy","name");


res.json(documents);


}catch(error){

res.status(500)
.json({
message:error.message
});

}

};



// View document details

exports.getDocument=async(req,res)=>{


try{


const document=
await Document.findById(req.params.id)
.populate("uploadedBy","name");


if(!document)
return res.status(404)
.json({
message:"Document not found"
});


res.json(document);



}catch(error){

res.status(500)
.json({
message:error.message
});

}


};




// Search Documents

exports.searchDocuments=async(req,res)=>{


try{


const keyword=req.query.q;


const documents=
await Document.find({

$or:[

{
title:{
$regex:keyword,
$options:"i"
}
},

{
category:{
$regex:keyword,
$options:"i"
}
}


]

});


res.json(documents);


}catch(error){

res.status(500)
.json({
message:error.message
});

}


};




// Download document

exports.downloadDocument=async(req,res)=>{


try{


const document=
await Document.findById(req.params.id);



if(!document)
return res.status(404)
.json({
message:"Document not found"
});



// Audit log can be added here


res.download(document.filePath);



}catch(error){

res.status(500)
.json({
message:error.message
});

}


};
