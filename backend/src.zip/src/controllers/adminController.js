const User=require("../models/User");

const Document=require("../models/Document");

const Department=require("../models/Department");

const bcrypt=require("bcrypt");



// Create Manager

exports.createManager=async(req,res)=>{


const password=
await bcrypt.hash(
req.body.password,
10
);


const manager=
await User.create({

name:req.body.name,

email:req.body.email,

password,

role:"MANAGER",

department:req.body.department

});


res.json({

message:"Manager created",

manager

});


};




// Delete Manager

exports.deleteManager=async(req,res)=>{


await User.findByIdAndDelete(
req.params.id
);


res.json({

message:"Manager deleted"

});


};




// Create Department

exports.createDepartment=async(req,res)=>{


const dept=
await Department.create({

name:req.body.name

});


res.json(dept);


};




// View all documents

exports.documents=async(req,res)=>{


const documents=
await Document.find();


res.json(documents);


};




// Delete any document

exports.deleteDocument=async(req,res)=>{


await Document.findByIdAndDelete(
req.params.id
);


res.json({

message:"Document deleted"

});


};