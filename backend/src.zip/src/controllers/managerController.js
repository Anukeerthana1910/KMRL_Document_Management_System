const User=require("../models/User");

const Document=require("../models/Document");




// Dashboard

exports.dashboard=async(req,res)=>{


const documents=
await Document.countDocuments();


const users=
await User.countDocuments();


res.json({

users,

documents

});


};




// View users

exports.users=async(req,res)=>{


const users=
await User.find({
role:"USER"
});


res.json(users);


};





// Upload Document

exports.uploadDocument=async(req,res)=>{


const document=
await Document.create({

title:req.body.title,

filePath:req.file.path,

category:req.body.category,

uploadedBy:req.user.id,


status:"Pending"

});


res.json({

message:"Document uploaded",

document

});


};




// View department documents

exports.documents=async(req,res)=>{


const documents=
await Document.find({

uploadedBy:req.user.id

});


res.json(documents);


};




// Approve document

exports.approve=async(req,res)=>{


await Document.findByIdAndUpdate(

req.params.id,

{
status:"Approved"
}

);


res.json({

message:"Document approved"

});


};




// Reject document

exports.reject=async(req,res)=>{


await Document.findByIdAndUpdate(

req.params.id,

{
status:"Rejected"
}

);


res.json({

message:"Document rejected"

});


};




// Reports

exports.reports=async(req,res)=>{


const total=
await Document.countDocuments();


res.json({

totalDocuments:total

});


};