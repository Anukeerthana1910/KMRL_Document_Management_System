const User=require("../models/User");



// View Profile

exports.getProfile=async(req,res)=>{


try{


const user=
await User.findByPk(
req.params.id
);



if(!user)
{
    return res.status(404).json({
        message:"User not found"
    });
}



res.json({

id:user.id,

name:user.name,

email:user.email,

role:user.role

});


}
catch(error){

res.status(500).json({
message:error.message
});

}


};