const express = require("express");

const router = express.Router();


const authMiddleware =
require("../middleware/authMiddleware");


const userController =
require("../controllers/userController");



// View profile

router.get(
"/profile",
authMiddleware,
userController.getProfile
);


// Optional

router.get(
"/my-documents",
authMiddleware,
userController.myDocuments
);



router.put(
"/profile",
authMiddleware,
userController.updateProfile
);



router.put(
"/change-password",
authMiddleware,
userController.changePassword
);



module.exports = router;