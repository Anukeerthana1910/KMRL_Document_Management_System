const router=require("express").Router();

const auth=require("../middleware/authMiddleware");

const role=
require("../middleware/roleMiddleware");


const controller=
require("../controllers/managerController");


router.get(
"/dashboard",
auth,
role(["MANAGER"]),
controller.dashboard
);


router.get(
"/users",
auth,
role(["MANAGER"]),
controller.users
);



router.post(
"/documents/upload",
auth,
role(["MANAGER"]),
controller.uploadDocument
);



router.get(
"/documents",
auth,
role(["MANAGER"]),
controller.documents
);



router.put(
"/documents/:id/approve",
auth,
role(["MANAGER"]),
controller.approve
);


router.put(
"/documents/:id/reject",
auth,
role(["MANAGER"]),
controller.reject
);



router.get(
"/reports",
auth,
role(["MANAGER"]),
controller.reports
);


module.exports=router;