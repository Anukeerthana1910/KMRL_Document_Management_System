const router=require("express").Router();

const auth=require("../middleware/authMiddleware");

const upload=
require("../middleware/uploadMiddleware");


const {
getDocuments,
getDocument,
downloadDocument,
searchDocuments
}=require("../controllers/documentController");


router.get("/",auth,getDocuments);

router.get("/:id",auth,getDocument);

router.get(
"/search",
auth,
searchDocuments
);


router.get(
"/:id/download",
auth,
downloadDocument
);
const commentController=
require("../controllers/commentController");


router.post(
"/:id/comments",
auth,
commentController.addComment
);



router.get(
"/:id/comments",
auth,
commentController.getComments
);

module.exports=router;