const router=require("express").Router();

const auth=require("../middleware/authMiddleware");

const role=
require("../middleware/roleMiddleware");


const admin=
require("../controllers/adminController");



router.post(
"/managers",
auth,
role(["ADMIN"]),
admin.createManager
);



router.delete(
"/managers/:id",
auth,
role(["ADMIN"]),
admin.deleteManager
);



router.post(
"/departments",
auth,
role(["ADMIN"]),
admin.createDepartment
);



router.get(
"/documents",
auth,
role(["ADMIN"]),
admin.documents
);



router.delete(
"/documents/:id",
auth,
role(["ADMIN"]),
admin.deleteDocument
);


module.exports=router;