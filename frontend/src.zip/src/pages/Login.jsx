import {useState,useContext} from "react";
import API from "../services/api";
import {AuthContext} from "../context/AuthContext";
import {useNavigate,Link} from "react-router-dom";
import "./Login.css";


const ROLE_TABS=[

{
key:"USER",
label:"User",
eyebrow:"User Login",
title:"Welcome back",
subtitle:"Sign in to upload, track and search documents.",
showSignup:true
},

{
key:"MANAGER",
label:"Manager",
eyebrow:"Department Head Login",
title:"Manager sign in",
subtitle:"Review, verify and approve documents for your department.",
showSignup:false
},

{
key:"ADMIN",
label:"Admin",
eyebrow:"Restricted Access",
title:"Administrator sign in",
subtitle:"Full system access.",
showSignup:false
}

];


export default function Login(){


const [selectedRole,setSelectedRole]=useState("USER");

const [email,setEmail]=useState("");

const [password,setPassword]=useState("");

const [error,setError]=useState("");

const [notice,setNotice]=useState("");

const [loading,setLoading]=useState(false);

const {login}=useContext(AuthContext);

const navigate=useNavigate();

const activeTab=ROLE_TABS.find(r=>r.key===selectedRole);



function selectRole(key){

setSelectedRole(key);
setError("");
setNotice("");

}



async function submit(e){

e.preventDefault();

setError("");
setNotice("");

setLoading(true);


try{

const res=await API.post(
"/auth/login",
{
email,
password
}
);


// backend currently returns { message, user:{id,name,email,role} }

login(res.data);


const actualRole=res.data.user?.role;


const destination=
actualRole==="ADMIN" ? "/admin" :
actualRole==="MANAGER" ? "/manager" :
"/employee";


if(actualRole && actualRole!==selectedRole){

setNotice(
`This account is registered as ${actualRole}. Redirecting to the ${actualRole.toLowerCase()} portal...`
);

setTimeout(()=>navigate(destination),1100);

}
else{

navigate(destination);

}


}
catch(err){

setError(
err.response?.data?.message ||
"Login failed. Please check your credentials."
);

}
finally{

setLoading(false);

}


}



return(

<div className={`auth-page auth-role-${selectedRole.toLowerCase()}`}>

<div className="auth-tricolour" aria-hidden="true">
<span></span>
<span></span>
<span></span>
</div>

<a href="#auth-main" className="auth-skip-link">Skip to main content</a>

<div className="auth-credential-bar">
<span>Government of Kerala Undertaking</span>
<span className="auth-credential-ref">File No. KMRL/IT/DMS/2026</span>
</div>

<main id="auth-main" className="auth-main">

<div className="auth-card">

<Link to="/" className="auth-back">
← Back to home
</Link>

<div className="auth-letterhead">

<Seal size={38} />

<div className="auth-letterhead-text">
<strong>KMRL</strong>
<span>Document Management System</span>
</div>

</div>


<div className="auth-role-tabs" role="tablist" aria-label="Select account type">

{ROLE_TABS.map(r=>(

<button
key={r.key}
type="button"
role="tab"
aria-selected={selectedRole===r.key}
className={"auth-role-tab" + (selectedRole===r.key ? " active" : "")}
onClick={()=>selectRole(r.key)}
>
{r.label}
</button>

))}

</div>


<p className="auth-eyebrow">{activeTab.eyebrow}</p>

<h1 className="auth-title">{activeTab.title}</h1>

<p className="auth-subtitle">
{activeTab.subtitle}
</p>


<form onSubmit={submit} className="auth-form">


{error && (
<div className="auth-error">
{error}
</div>
)}


{notice && (
<div className="auth-success">
{notice}
</div>
)}


<label className="auth-label">
Email

<input
className="auth-input"
type="email"
placeholder="you@kmrl.co.in"
value={email}
required
onChange={e=>setEmail(e.target.value)}
/>
</label>


<label className="auth-label">
Password

<input
className="auth-input"
type="password"
placeholder="••••••••"
value={password}
required
onChange={e=>setPassword(e.target.value)}
/>
</label>


<button
className="auth-button"
disabled={loading}
>
{loading ? "Signing in..." : `Sign in as ${activeTab.label}`}
</button>


</form>

{activeTab.showSignup && (

<p className="auth-footnote">
New member? <Link to="/signup">Create an account</Link>
</p>

)}

<p className="auth-footnote">
Academic project prototype &middot; Not an official government system
</p>

</div>

</main>

</div>

)

}



function Seal({ size = 40 }) {

  const stroke = "#0B2545";
  const fill = "#F7F4EE";

  return (

    <svg
      width={size}
      height={size}
      viewBox="0 0 64 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      aria-hidden="true"
    >

      <circle cx="32" cy="32" r="30" stroke={stroke} strokeWidth="2" />
      <circle cx="32" cy="32" r="24" stroke={stroke} strokeWidth="1" />

      {/* stylised rail arc */}
      <path
        d="M14 36 A18 18 0 0 1 50 36"
        stroke={stroke}
        strokeWidth="2.5"
        strokeLinecap="round"
        fill="none"
      />

      <circle cx="14" cy="36" r="2.5" fill={stroke} />
      <circle cx="32" cy="20.5" r="2.5" fill={stroke} />
      <circle cx="50" cy="36" r="2.5" fill={stroke} />

      {/* document glyph */}
      <rect x="26" y="38" width="12" height="15" rx="1.5" stroke={stroke} strokeWidth="2" fill={fill} />
      <line x1="29" y1="43" x2="35" y2="43" stroke={stroke} strokeWidth="1.4" />
      <line x1="29" y1="47" x2="35" y2="47" stroke={stroke} strokeWidth="1.4" />

    </svg>

  );

}